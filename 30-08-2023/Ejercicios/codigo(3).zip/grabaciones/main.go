package main

import "fmt"

func main() {
	resultado := suma(4, 8)
	fmt.Println("El resultado es:", resultado)
}

func suma(a, b int) int {

	return a + b
}
